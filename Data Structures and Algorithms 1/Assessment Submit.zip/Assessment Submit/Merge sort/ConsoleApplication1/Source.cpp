//merge sort with vectors


#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <list>
#include <vector>

// Import things we need from the standard library
using std::cin;
using std::chrono::duration_cast;
using std::chrono::microseconds;
using std::chrono::steady_clock;
using std::cout;
using std::endl;
using std::list;
using std::ofstream;
using std::sort;
using std::vector;

typedef std::chrono::steady_clock the_clock;

//generate random numbers, the amount depending on what is passed in. 
template <typename T>
void MakeRandomValues(T& collection, int count) {
	for (int i = 0; i < count; i++) {
		collection.push_back(rand() % 100);
	}
}

template <typename T>
void MakeExistingValues(T& collection, int count) {
	for (int i = 0; i <= count; i++) {
		collection.push_back(i);
	}
}

// Print out all the items in the list.
template <typename T>
void ShowValues(const T& collection) {
	for (auto item : collection) {
		cout << " " << item;
	}
	cout << "\n";
}

void mergeSort(vector<int>&left, vector<int>& right, vector<int>& bars)
{
	int LeftSize = left.size();
	int RightSize = right.size();
	int i = 0, j = 0, k = 0;

	while (j < LeftSize && k < RightSize)
	{
		if (left[j] < right[k]) {
			bars[i] = left[j];
			j++;
		}
		else {
			bars[i] = right[k];
			k++;
		}
		i++;
	}
	while (j < LeftSize) {
		bars[i] = left[j];
		j++; i++;
	}
	while (k < RightSize) {
		bars[i] = right[k];
		k++; i++;
	}
}


void sort(vector<int> & number) {
	//if the vector is already sorted
	if (number.size() <= 1) return;

	int mid = number.size() / 2;
	vector<int> left;
	vector<int> right;

	for (size_t j = 0; j < mid; j++) {
		left.push_back(number[j]);
	}

	for (size_t j = 0; j < (number.size()) - mid; j++) {
		right.push_back(number[mid + j]);
	}

	sort(left);
	sort(right);
	mergeSort(left, right, number);
}



int main() {

	float average = 0;
	int num_values;

	ofstream Mergefile("MergefileRandom.csv");

	for (num_values = 0; num_values < 1500; num_values += 100) {
		for (int i = 0; i < 100; i++) {
			//srand((unsigned int)time(NULL));


			vector<int> input;

			MakeRandomValues(input, num_values);


			the_clock::time_point start = the_clock::now();
			sort(input);
			the_clock::time_point end = the_clock::now();

			float time_taken = duration_cast<microseconds>(end - start).count();
			average = average + time_taken;
		}

		//cout << "Numbers: " << num_values << endl;
		average = average / 100;
		Mergefile << num_values << "," << average << "\n";
		//cout << "average time: " << average << "ms" << endl;
	}

	cout << "All OK! Press return to exit...\n";
	cin.get();
}





