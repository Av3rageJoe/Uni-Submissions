// Insertion sort on vectors


#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <list>
#include <vector>

// Import things we need from the standard library
using std::cin;
using std::chrono::duration_cast;
using std::chrono::microseconds;
using std::chrono::steady_clock;
using std::cout;
using std::endl;
using std::list;
using std::ofstream;
using std::sort;
using std::vector;

typedef std::chrono::steady_clock the_clock;

//generate random numbers, the amount depending on what is passed in. 
template <typename T>
void MakeRandomValues(T& collection, int count) {
	for (int i = 0; i < count; i++) {
		collection.push_back(rand() % 100);
	}
}

//Creates the vector in sequential order
template <typename T>
void MakeExistingValues(T& collection, int count) {
	for (int i = 0; i <= count; i++) {
		collection.push_back(i);
	}
}

// Creates the vector in reverse order
template <typename T>
void MakeExistingValuesReverse(T& collection, int count) {
	for (int i = count; i >= 0; i--) {
		collection.push_back(i);
	}
}


// Print out all the items in the list.
template <typename T>
void ShowValues(const T& collection) {
	for (auto item : collection) {
		cout << " " << item;
	}
	cout << "\n";
}

template <typename T>
void InsertionSort(T& collect) {
	vector<int> output;
	int size = collect.size();
	for (int i = 0; i < size; i++) {
		int item = *(collect.begin());
		InsertOrdered(output, item);
		collect.erase(collect.begin());
	}
	//cout << "After sorting: " << endl;
	//ShowValues(output);
}

template <typename T>
void InsertOrdered(T& vector, int item) {
	auto it = vector.begin();
	while (it != vector.end()) {
		if (*it > item)
		{
			vector.insert(it, item);
			return;
		}
		it++;
	}
	vector.push_back(item);
}


int main(int argc, char *argv[]) {

	//float average = 0;
	//amount of integers that will be sorted
	int num_values;
	vector<int> input;

	//ofstream InsertionSorting("InsertionSortRandom2.0.csv");

	for (num_values = 0; num_values < 1500; num_values += 100) {
		for (int i = 0; i < 100; i++) {
			//cout << "Sorting " << num_values << " integers\n";
			// generate a random time for the RNG
			srand((unsigned int)time(NULL));

			
			MakeRandomValues(input, num_values);

			//put here the insertion sort function call
			//the_clock::time_point start = the_clock::now();
			InsertionSort(input);
			//the_clock::time_point end = the_clock::now();

			//float time_taken = duration_cast<microseconds>(end - start).count();

			//cout << endl;
			//average = average + time_taken;


		}


		//average = average / 100;
		//InsertionSorting << num_values << "," << average << "\n";
		//cout << "average time: " << average << "ms" << endl;



	}



	//cout << "Time taken: " << time_taken << endl;
	cout << "All OK! Press return to exit...\n";
	cin.get();

	return 0;
}