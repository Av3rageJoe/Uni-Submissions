package com.example.admin.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListDataActivity extends AppCompatActivity {

    Button HistoryBtn;
    DatabaseHelper mDatabaseHelper;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);

        mListView = (ListView) findViewById(R.id.listView);
        mDatabaseHelper = new DatabaseHelper(this);

        //Call the function that will add items to the list view from the database
        populateListView();
    }

    private void populateListView() {

        //get the data and append to a list
        Cursor data = mDatabaseHelper.getData();
        ArrayList<String> listData = new ArrayList<>();


        while(data.moveToNext()){
            //get the value from the database in column's 1 and 2
            //then add it to the ArrayList
            listData.add(data.getString(1) + ", " + data.getString(2));
        }
        //create the list adapter and set the listview to the contents of the adapter
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        mListView.setAdapter(adapter);

        //set an onItemClickListener to the ListView
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final String name = adapterView.getItemAtPosition(i).toString();

                String DatabaseContent = name;
                //Extract the date
                String[] parts = DatabaseContent.split(", ");
                String DatabaseDate = parts[1]; // 034556

                Cursor data = mDatabaseHelper.getItemID(DatabaseDate); //get the id associated with that name

                int itemID = -1;
                while(data.moveToNext()){
                    itemID = data.getInt(0);
                }
                if(itemID > -1){
                    final int ID = itemID;
                    final AlertDialog.Builder builder = new AlertDialog.Builder(ListDataActivity.this);
                    builder.setMessage("Would you like to delete this item?")
                            .setCancelable(true)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                                //If the user presses yes...
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Call the function to delete that column
                                    mDatabaseHelper.deleteName(ID,name);
                                    Toast.makeText(getApplicationContext(), "Item removed from database", Toast.LENGTH_LONG).show();
                                    populateListView();

                                }
                            })
                            //If the user chooses no, then close the pop up
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                                    dialog.cancel();
                                }
                            });
                    //Display the message
                    final AlertDialog DeleteItem = builder.create();
                    DeleteItem.show();

                }
                else{
                    Toast.makeText(getApplicationContext(), "No ID assosciated with that name", Toast.LENGTH_LONG).show();
                }
            }
        });

    }



}
