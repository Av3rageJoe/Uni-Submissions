package com.example.admin.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class History extends AppCompatActivity implements View.OnClickListener, GestureDetector.OnGestureListener{

    Button HistoryBtn;
    DatabaseHelper mDatabaseHelper;
    GestureDetector mGestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        HistoryBtn = (Button) findViewById(R.id.HistoryBtn);
        HistoryBtn.setOnClickListener(this);

        //Register an instance of the databseHelper class
        mDatabaseHelper = new DatabaseHelper(this);

        //Set up the Gesture Listener
        mGestureDetector = new GestureDetector(this, this);
    }

    @Override
    public void onClick(View v) {
                //This intent will call a class that will display a listview with the contents of the database
                Intent intent = new Intent(this, ListDataActivity.class);
                startActivity(intent);
    }


    public void DeleteDatabase() {
        //Calls the method to delete the database
        mDatabaseHelper.deleteTable();

    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    //Whgen the user flings, clear the database
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        mDatabaseHelper.deleteTable();
        Toast.makeText(this,"Database deleted!", Toast.LENGTH_SHORT).show();
        return true;
    }

    //The gesture Listener for when an event occurs
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
}
