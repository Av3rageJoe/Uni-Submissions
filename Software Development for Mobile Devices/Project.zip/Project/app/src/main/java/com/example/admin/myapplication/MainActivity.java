package com.example.admin.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Spinners are drop down menus with different options
    Spinner MateOrDate;
    Spinner HowManyPeople;

    Button PartnerDate;
    Button FriendsDate;
    Button HistoryBtn;

    TextView HowManyFriendstxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Add listener for the history button
        HistoryBtn = findViewById(R.id.HistoryBtn);
        HistoryBtn.setOnClickListener(this);

        //Add listener for partner button
        PartnerDate = (Button) (findViewById(R.id.FindDateBtn));
        PartnerDate.setOnClickListener(this);

        //Add listener for Friends button
        FriendsDate = (Button) (findViewById(R.id.FriendEventBtn));
        FriendsDate.setOnClickListener(this);

        HowManyFriendstxt = (TextView) (findViewById(R.id.FriendsText));

        //declare the first spinner and add dropdown options
        MateOrDate = findViewById(R.id.WhoWithOption);
        String[] items = new String[]{"Partner", "Friends",};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        MateOrDate.setAdapter(adapter);

        //declare the first spinner and add dropdown options
        HowManyPeople = findViewById(R.id.HowMany);
        String[] words = new String[]{"2", "3", "4", "5", "6+"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, words);
        HowManyPeople.setAdapter(adapter1);

        //Add a listener that will get the value of the Friends or date spinner, and update the UI
        MateOrDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                String WhoWith = MateOrDate.getSelectedItem().toString();

                //If the option for the date or Friends spinner is date, then add a button to go to the Friends class passing in that it is with a date. Else ask how many people will be there
                if(WhoWith.equals("Partner")) {

                    PartnerDate.setVisibility(View.VISIBLE);
                    HowManyFriendstxt.setVisibility(View.INVISIBLE);
                    HowManyPeople.setVisibility(View.INVISIBLE);
                    FriendsDate.setVisibility((View.INVISIBLE));
                    HistoryBtn.setVisibility(View.VISIBLE);
                }

                else if(WhoWith.equals("Friends")){
                    PartnerDate.setVisibility(View.INVISIBLE);
                    HowManyFriendstxt.setVisibility(View.VISIBLE);
                    HowManyPeople.setVisibility(View.VISIBLE);
                    FriendsDate.setVisibility((View.VISIBLE));
                   // HistoryBtn.setVisibility(View.GONE);

                }
            }

            //Necessary to make listener work - however, a value will always be selected
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Toast.makeText(getApplicationContext(), "An error ahs occurred", LENGTH_SHORT).show();
            }

        });



    }

    @Override
    public void onClick(View v) {

        switch(v.getId()) {

            //If the date button is pressed then call the Friends class passing in the date option
            case R.id.FindDateBtn:
                Intent DateIntent = new Intent(getApplicationContext(), Friends.class);
                DateIntent.putExtra("Date", "Date");
                startActivity(DateIntent);
                break;

            //If the Friends button is pressed then call the Friends class passing in how many people are selected
            case R.id.FriendEventBtn:
                Intent FriendIntent = new Intent(getApplicationContext(), Friends.class);
                FriendIntent.putExtra("NumberOfPeopleSend", HowManyPeople.getSelectedItem().toString());
                startActivity(FriendIntent);
                break;

            //If the history button is pressed then load up the history class
            case R.id.HistoryBtn:
                Intent intent = new Intent(this, History.class);
                startActivity(intent);
                break;
        }
    }
}
