#pragma once
#include <iostream>

class Loan
{
public:
	Loan();
	~Loan();

	void setInterestRate(double I);
	void getLoan(double *balance, double LoanAmount1, int LoanTerm);

private: 
	double InterestRate;
};

