#include <iostream>
#include<string>
#include "ID.h"
#include <ctype.h>
#include "Loan.h"

using namespace std;
ID::ID()
{
}

ID::~ID()
{
}

void ID::setBalance(double B) {
	balance = B;
}

double ID::getBalance() {
	return balance;
}

void ID::setAccName(string A) {
	AccName = A;
}

string ID::getAccName() {
	return AccName;
}

void ID::setuserID(int U) {
	userID = U;
}




int ID::getuserID() {
	return userID;
}

void ID::setCustNum(int C) {
	CustNum = C;
}

void ID::setPin(int P) {
	Pin = P;
}

int ID::getPin() {
	return Pin;
}

int ID::getCustNum() {
	return CustNum;
}


//declare all functions
void loans(double *balance);

int overdraftAmount = 0;
int NumberOfAccounts[3];
double *CustBalance;

void ID::deposit() {
	double DepAmount;
	bool check = false;

	while (check == false) {
		cout << "How much would you like to deposit?" << endl;
		cin >> DepAmount;

		if (DepAmount <= 0) {
			cout << "The amount you entered is not a valid amount" << endl;
		}
		else if (DepAmount > 0) {
			balance = balance + DepAmount;
			cout << "Your new balance is: " << char(156) << balance << endl;
			check = true;
		}
	}
}


bool ID::withdrawal(double withdrawalAmount) {

		if (withdrawalAmount <= (balance + (overdraftAmount * -1)) && withdrawalAmount > 0) {
			balance = balance - withdrawalAmount;
			cout << "Your new balance is: " << char(156) << balance << endl;
			return true;
		}
		else if ((balance - withdrawalAmount) < overdraftAmount) {
			cout << "You do not have sufficient funds to carry out this transaction" << endl;
		}
		else {
			cout << "The amount you entered is invalid" << endl;
		}
	}



void ID::withdrawal() {
	//let the user withdraw �10 if they have sufficent funds
	if ((balance - 10) < overdraftAmount) {
		cout << "You do not have sufficient funds to carry out this transaction" << endl;
	}
	else if ((balance - 10) > overdraftAmount) {
		balance = balance - 10;
		cout << char(156) << "10 has successfully been withdrawan from your account" << endl;
		cout << "Your new account balance is " << char(156) << balance << endl;

	}
}

void ID::loan() {
	loans(&balance);
}

void loans(double *balance) {
	Loan Cust;

	double LoanTerm;
	double LoanAmount;
	bool check = false;



	while (check == false) {
		cout << "How much money would you like to borrow?" << endl;
		cin >> LoanAmount;
		if (LoanAmount < 0) {
			cout << "The amount you entered is not a valid amount" << endl;
		}
		else if (LoanAmount >(*balance * 2)) { // make sure that the user is not trying to borrow more than double their balance
			cout << "The amount you are applying for is more than double your balance. Please enter an amount less than double your balance" << endl;
		}
		else check = true;
	}

	check = false;
	while (check == false) {
		cout << "How many months would you like to take the loan of " << char(156) << LoanAmount << " out over" << endl; // find out how long the user wants the term to be
		cin >> LoanTerm;
		if (LoanTerm < 0) { // if the term they entered is negative output that it is not valid
			cout << "The term you entered is not valid" << endl;
		}
		else check = true;
	}

	Cust.getLoan(balance,LoanAmount,LoanTerm);
}

void ID::overdraft() {
	overdraftAmount = -500; // change the lower limit of the account to - 500
	cout << "Your new overdraft balance is - " << char(156) << "500" << endl;
}

void ID::newAccount(int custID) {
	if (custID == 1) {
		if (NumberOfAccounts[0] < 4) {			// checks to make sure that the customer is not trying to create more than 5 accounts.
			NumberOfAccounts[0]++;
			cout << "A new account has been created. Your customer number for this account is: " << NumberOfAccounts[0] + 1 << endl;
		}
		else cout << "You have already reached the maximum account limit of 5" << endl;
	}
	else if (custID == 2) {
		if (NumberOfAccounts[1] < 4) {
			NumberOfAccounts[1]++;
			cout << "A new account has been created. Your customer number for this account is: " << NumberOfAccounts[1] + 1 << endl;
		}
		else cout << "You have already reached the maximum account limit of 5" << endl;
	}
	else if (custID == 3) {
		if (NumberOfAccounts[2] < 4) {
			NumberOfAccounts[2]++;
			cout << "A new account has been created. Your customer number for this account is: " << NumberOfAccounts[2] + 1 << endl;
		}
		else cout << "You have already reached the maximum account limit of 5" << endl;
	}
}