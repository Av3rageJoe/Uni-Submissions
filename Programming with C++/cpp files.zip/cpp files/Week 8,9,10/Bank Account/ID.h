#pragma once
#include <string>
#include <iostream>
using namespace std;


class ID
{
public:
	ID();
	~ID();

	double getBalance();
	int getuserID();
	int getCustNum();
	int getPin();
	string getAccName();

	void setBalance(double B);
	void setuserID(int U);
	void setCustNum(int C);
	void setPin(int P);
	void setAccName(string S);

	void menu(int userAns);
	void deposit();
	bool withdrawal(double withdrawalAmount);
	void withdrawal();
	void loan();
	void overdraft();
	void newAccount(int custID);

private:
	int userID;
	double balance;
	int CustNum;
	int Pin;
	string AccName;


};

