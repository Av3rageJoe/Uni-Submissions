#include <iostream>
#include <string>
#include "ID.h"
#include <algorithm>

using namespace std;

string convert(string upper);
void search(int CustID, int CustNumber, int userAns);

// an array of objects for each users accounts
ID Connor[5]; 
ID Rory[5];
ID Michael[5];

int menu(int custID);
int questions();
void userRequest(int userAns);

int custID;
int CustNumber;
int CurrentAccounts[3]; // a variable that stores the amount of accounts the customer currently has


int main() {

	string CapWord;
	string PerformAction;
	bool check = false;
	int userAns = 0; // a variable that holds what the user enters from the menu

	CurrentAccounts[0] = 1; // sets the amount of accounts the customer currently has to 1
	CurrentAccounts[1] = 1;
	CurrentAccounts[2] = 1;

	for (int x = 0; x < 5; x++) {					// sets up all the objects to their corresponding userID's
		Connor[x].setuserID(1);
		Rory[x].setuserID(2);
		Michael[x].setuserID(3);
		Connor[x].setAccName("Connor");
		Rory[x].setAccName("Rory");
		Michael[x].setAccName("Michael");
	}

	Connor[0].setBalance(13000);
	Rory[0].setBalance(3000);
	Michael[0].setBalance(1900);

	for (int x = 1; x < 5; x++) {
		Connor[x].setBalance(0);					// sets all new account balances for Connor to �0
		Rory[x].setBalance(0);						// sets all new account balances for Rory to �0
		Michael[x].setBalance(0);					// sets all new account balances for Michael to �0
	}




	for (int x = 0; x < 5; x++) {
		Connor[x].setCustNum(x + 1);
		Rory[x].setCustNum(x + 1);
		Michael[x].setCustNum(x + 1);
	}



	for (int x = 0; x < 5; x++) {
		Connor[x].setPin(1327);
		Rory[x].setPin(6397);
		Michael[x].setPin(3253);
	}

	

	userAns = questions();
	
	if (userAns == 8) {
		userAns = questions();
	}

	

	while (check == false) {
		cout << "Would you like to perform another action?" << endl;
		cin >> PerformAction;

		CapWord = convert(PerformAction);

		if (CapWord == "YES") {
			userAns = menu(custID); // calls the menu function to find out what the user is requesting
			if (userAns == 8) {
				userAns = questions();
			}
			search(custID, CustNumber, userAns); // carrys out the users request
		}
		else check = true;
	}


	cout << "Press ENTER to continue...";
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	cin.get();


	return 0;


}

string convert(string upper) {

	transform(upper.begin(), upper.end(), upper.begin(), ::toupper); // turns the string passed in into capitals

	return upper;
}




int questions() {
	bool check = false;
	bool pin = false;
	bool check2 = false;
	int CustPin;
	int userAns;
	while (check == false) {
		while (check2 == false) {
			cout << "Please enter a user ID" << endl;
			cin >> custID;

			cout << "Please enter an Account number" << endl;
			cin >> CustNumber;

			if ((custID == 1 && CustNumber > CurrentAccounts[0]) || (custID == 2 && CustNumber > CurrentAccounts[1]) || (custID <= 0 || custID > 3 || CustNumber <= 0) || (custID <= 0 || custID > 3 || CustNumber <= 0)) {
				cout << "The account you entered does not exist" << endl;
			}
			else check2 = true;
		}


		// a loop to check that the pin entered by the user matches the pin linked to the account.
		while (pin == false) {
			cout << "Please enter your Pin" << endl;
			cin >> CustPin;

			if (custID == 1) {
				if (CustPin == Connor[CustNumber - 1].getPin()) { // a series of if statements for each account.				
					userAns = menu(custID); // gets the user input from the menu
					pin = true; // sets the pin variable to true
					if (userAns == 8) { // if the user wishes to change accounts then stop the code so that it can jump back to asking the initial questions
						return userAns;
						break;
					}

					else {
						search(custID, CustNumber, userAns); // call the search function to call the class and fulfill the users request
						check = true;
					}
				}
			}

			else if (custID == 2) {
				if (CustPin == Rory[CustNumber - 1].getPin()) {
					userAns = menu(custID);
					pin = true;
					if (userAns == 8) {
						return userAns;
						break;
					}
					else {
						
						search(custID, CustNumber, userAns);
						check = true;
					}
				}
			}

			else if (custID == 3) {
				if (CustPin == Michael[CustNumber - 1].getPin()) {
					userAns = menu(custID);
					pin = true;
					if (userAns == 8) {
						return userAns;
						break;
					}
					else {
						
						search(custID, CustNumber, userAns);
						check = true;
					}
				}
			}
		}
	}

	return 0;

}

int menu(int custID) { // finds out what the customer's request is

	int userAns;
	switch (custID) {
	case 1:
		cout << "\t Welcome to Abertay Bank " << Connor[1].getAccName() << endl; break;

	case 2:
		cout << "\t Welcome to Abertay Bank " << Rory[1].getAccName() << endl; break;

	case 3:
		cout << "\t Welcome to Abertay Bank " << Michael[1].getAccName() << endl; break;
	}
	cout << endl;
	cout << endl;
	cout << "\t Please only enter numbers throughout the program." << endl;
	cout << "\t Please select a number from the following list:" << endl;
	cout << endl;
	cout << "\t \t 1) View your balance" << endl;
	cout << "\t \t 2) Make a deposit" << endl;
	cout << "\t \t 3) Make a withdrawal" << endl;//add another menu option with a quick withdraw �10
	cout << "\t \t 4) Make a quick withdrawal of " << char(156) << "10" << endl;
	cout << "\t \t 5) Take out a loan" << endl;
	cout << "\t \t 6) Take out an overdraft" << endl;
	cout << "\t \t 7) Take out a new account" << endl;
	cout << "\t \t 8) Swap accounts" << endl;

	cin >> userAns;


	return userAns;

}


void search(int custID, int CustNumber, int userAns) { // a function to loop through the classes, find the correct one that the user is accessing, and then call the corresponding class

	for (int y = 0; y < 6; y++) { //checks to see if the id number that the customer entered matches the id number that was passed in

		if (custID == 1 && Connor[y].getCustNum() == CustNumber) {
			
			if (userAns == 7) { // increment the currentAccounts variable
				CurrentAccounts[0]++;
				if (CurrentAccounts[0] > 5) {
					CurrentAccounts[0] = 5; // sets the current accounts variable to 5, so that they can not access accounts that do not exist
				}
			}

			userRequest(userAns); // handles the users request.
			break;
		}
		else if (custID == 2 && Rory[y].getCustNum() == CustNumber) {
			
			if (userAns == 7) { // increment the currentAccounts variable
				CurrentAccounts[1]++;
				if (CurrentAccounts[1] > 5) {
					CurrentAccounts[1] = 5; 
				}
			}
			
			userRequest(userAns); // handles the users request.
			break;
		}
		else if (custID == 3 && Michael[y].getCustNum() == CustNumber) {
			
			if (userAns == 7) { // increment the currentAccounts variable
				CurrentAccounts[2]++;
				if (CurrentAccounts[2] > 5) {
					CurrentAccounts[2] = 5;
				}
			}
		}
			userRequest(userAns); // handles the users request.
			break;
		}
	}

void userRequest(int userAns) {

	bool check = false;

	switch (userAns) {
	case 1:
		switch (custID) {
		case 1:
			cout << "Your balance is: " << char(156) << Connor[CustNumber - 1].getBalance() << endl;
			break;

		case 2:
			cout << "Your balance is: " << char(156) << Rory[CustNumber-1].getBalance() << endl;
			break;

		case 3:
			cout << "Your balance is: " << char(156) << Michael[CustNumber-1].getBalance() << endl;
			break;

		}
		break;
	case 2:
		switch (custID) {
		case 1:
			Connor[CustNumber-1].deposit();
			break;

		case 2:
			Rory[CustNumber-1].deposit();
			break;

		case 3:
			Michael[CustNumber-1].deposit();
			break;

		}
		break;

	case 3:

		while (check == false) {

			double withdrawalAmount;

			cout << "How much would you like to withdraw?" << endl;
			cin >> withdrawalAmount;

			switch (custID) {
			case 1:
				check = Connor[CustNumber-1].withdrawal(withdrawalAmount);
				break;

			case 2:
				check = Rory[CustNumber-1].withdrawal(withdrawalAmount);
				break;

			case 3:
				check = Michael[CustNumber-1].withdrawal(withdrawalAmount);
				break;
			}
		}
		break;

	case 4:

		switch (custID) {
		case 1:
			Connor[CustNumber-1].withdrawal();
			break;

		case 2:
			Rory[CustNumber-1].withdrawal();
			break;

		case 3:
			Michael[CustNumber-1].withdrawal();
			break;
		}
		break;

	case 5:

		switch (custID) {
		case 1:
			Connor[CustNumber-1].loan();
			break;

		case 2:
			Rory[CustNumber-1].loan();
			break;

		case 3:
			Michael[CustNumber-1].loan();
			break;
		}
		break;

	case 6:
		switch (custID) {
		case 1:
			Connor[CustNumber-1].overdraft();
			break;

		case 2:
			Rory[CustNumber-1].overdraft();
			break;

		case 3:
			Michael[CustNumber-1].overdraft();
			break;
		}
		break;

	case 7:
		switch (custID) {
		case 1:
			Connor[CustNumber-1].newAccount(custID);
			break;

		case 2:
			Rory[CustNumber-1].newAccount(custID);
			break;

		case 3:
			Michael[CustNumber-1].newAccount(custID);
			break;
		}
		break;

		case 8:
			questions();
	}
}
