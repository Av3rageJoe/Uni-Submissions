#include "Loan.h"
#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

double LoanAmount;

Loan::Loan()
{
	if (0 < LoanAmount && LoanAmount < 2500) {
		InterestRate = 12.5;
	}
	else if (2500 <= LoanAmount && LoanAmount < 5000) {
		InterestRate = 7.5;
	}
	else if (5000 <= LoanAmount && LoanAmount < 7500) {
		InterestRate = 4.3;
	}
	else if (7500 <= LoanAmount && LoanAmount < 25000) {
		InterestRate = 3.4;
	}
	else if (25000 <= LoanAmount && LoanAmount < 30000) {
		InterestRate = 3.9;
	}
	else if (30000 <= LoanAmount && LoanAmount < 40000) {
		InterestRate = 6.8;
	}
	else InterestRate = 7.5;
}


Loan::~Loan()
{
}

void Loan::setInterestRate(double I) {
	InterestRate = I;
}



void interest(double *balance, int LoanTerm, double InterestRate); // a function to calculate the amount of interest charged
void LoanDetails(double interest, double LoanTerm, double *balance); // a function to display the lona details



void Loan::getLoan(double *balance, double LoanAmount1, int LoanTerm) {

	LoanAmount = LoanAmount1;



	interest(balance, LoanTerm, InterestRate);
}

void interest(double *balance, int LoanTerm, double InterestRate) {
	double interest;

	interest = ((LoanAmount / 100) * InterestRate);

	LoanDetails(interest, LoanTerm, balance);

}

void LoanDetails(double interest, double LoanTerm, double *balance) {
	double MonthlyPayments;
	MonthlyPayments = (LoanAmount + interest) / LoanTerm;

	cout << endl;
	cout << endl;
	cout << "\t Your loan amount is: " << char(156) << LoanAmount << endl;
	cout << "\t The amount of interest you will pay on your loan is: " << fixed << setprecision(2) << char(156) << interest << endl;
	cout << "\t Your monthly Payments are: " << char(156) << fixed << setprecision(2) << MonthlyPayments << endl;
	cout << endl;

	*balance = *balance + LoanAmount;
}