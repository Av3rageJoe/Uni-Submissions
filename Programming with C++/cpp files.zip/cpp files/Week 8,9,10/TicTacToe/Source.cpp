#include <iostream>
#include<string>
#include<cstdlib>
#include <ctime>	// used to get date and time information
using namespace std;

const int NUM_ROWS = 3;								// declares variables
const int NUM_COLUMNS = 3;
char tictactoe_game[NUM_ROWS][NUM_COLUMNS];
bool winCheck = false;
int winCount = 0;

void grid();
void userPlay(int num, char letter);
void updatedGrid();
void diagonalCheck(char letter, string user);
void verticalCheck(char letter, string user);
void horizontalCheck(char letter, string user);
bool isBoardFull();
void AImove();
void RNG();

int main()
{
	int ComputerOrUser;
	bool check = false;

	while (check == false) {
		cout << "Would you like to play against the computer or another user?" << endl;
		cout << "Press 1 to play against the computer or 2 to play against another user" << endl;
		cin >> ComputerOrUser;

		if (ComputerOrUser == 1 || ComputerOrUser == 2) {
			check = true;
		}
	}

	switch (ComputerOrUser) {
	case 1:
		grid(); // sets up the grid


		for (int i = 0; i < 10; i++)								// loops until all the spaces in the grid are filled
		{

			userPlay(1, 'X');

			updatedGrid();

			horizontalCheck('X', "Congratulations, you won!");

			verticalCheck('X', "Congratulations, you won!");

			diagonalCheck('X', "Congratulations, you won!");

			if (winCheck == true) {
				cout << "Press ENTER to continue...";
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				cin.get();
				break;
			}																	// If player 1 wins then the code will stop
			cout << "Computers move... " << endl;

			AImove();

			updatedGrid();

			horizontalCheck('O', "The computer wins");

			verticalCheck('O', "The computer wins");

			diagonalCheck('O', "The computer wins");


			if (winCheck == true) {
				cout << "Press ENTER to continue...";
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				cin.get();
				break;
			}
		} break;
	case 2:
		grid(); // sets up the grid


		for (int i = 0; i < 10; i++)								// loops until all the spaces in the grid are filled
		{

			userPlay(1, 'X');

			updatedGrid();

			horizontalCheck('X', "Congratulations player 1, you won!");

			verticalCheck('X', "Congratulations player 1, you won!");

			diagonalCheck('X', "Congratulations player 1, you won!");

			if (winCheck == true) {
				cout << "Press ENTER to continue...";
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				cin.get();
				break;
			}																	// If player 1 wins then the code will stop


			userPlay(2, 'O');

			updatedGrid();

			horizontalCheck('O', "Congratulations player 2, you won!");

			verticalCheck('O', "Congratulations player 2, you won!");

			diagonalCheck('O', "Congratulations player 2, you won!");

			if (winCheck == true) {
				cout << "Press ENTER to continue...";
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				cin.get();
				break;
			}
		} break;
	} 
}

void grid() {
	for (int row = 0; row < NUM_ROWS; row++)			// sets up the grid
	{
		for (int column = 0; column < NUM_COLUMNS; column++)
		{
			tictactoe_game[row][column] = ' ';
		}
	}

}

void userPlay(int num, char letter) {
	int x;											//declare variables
	int y;
	bool check = false;

	while (check == false) {
		cout << " User " << num << " Please enter an X co ordinate" << endl; // gets user input
		cin >> y;

		cout << "User " << num << " Please enter a Y co ordinate" << endl;
		cin >> x;
	
		if ((x == 0 || x == 1 || x == 2) && (y == 0 || y == 1 || y == 2)) { // checks that the co ordinates being entered are valid
			if (tictactoe_game[x][y] == ' ') {								// checks to make sure that the space the user is trying to enter is not full
				check = true;
				tictactoe_game[x][y] = letter;								// enters the users character (X or O)

			}
			else cout << "That position is already filled" << endl;
		}
		else cout << "The co ordinates you entered are not valid" << endl;
	}		
}

void updatedGrid() {											// displays the updated grid
	
	for (int row = 0; row < NUM_ROWS; row++)				
	{
		for (int column = 0; column < NUM_COLUMNS; column++)
		{
			cout << tictactoe_game[row][column];
		}
		cout << endl;
	}
		
}

void horizontalCheck(char letter, string user) {
	for (int row = 0; row < NUM_ROWS; row++)
	{
		for (int i = 0; i < 3; i++) {
			if (tictactoe_game[row][i] == letter) // tests each row to see if there are 3 O's in a row.
			{
				winCount++;
				if (winCount == 3)
				{
					winCheck = true;
					cout << user << endl; // displays the winner
				}
			}
		}
		winCount = 0;

	}
}

void verticalCheck(char letter, string user) {
	for (int column = 0; column < NUM_COLUMNS; column++)			// creates a loop to heck for a vertical win for "X"
	{
		for (int i = 0; i < 3; i++) {
			if (tictactoe_game[i][column] == letter)					// tests each column to see if there is a vertical win for "X"
			{
				winCount++;
				if (winCount == 3)									// checks if there are 3 "X"'s in a row
				{
					winCheck = true;
					cout << user << endl; // displays the winner if there are 3 vertical "X"'s
				}
			}
		}
		winCount = 0;												// resets winCount if there is not 3 X's in a column

	}
}

void diagonalCheck(char letter, string user) {
	if (tictactoe_game[0][0] == letter && tictactoe_game[1][1] == letter && tictactoe_game[2][2] == letter) {
		winCheck = true;
		cout << user << endl;
	}

	if (tictactoe_game[2][0] == letter  && tictactoe_game[1][1] == letter && tictactoe_game[0][2] == letter) {
		winCheck = true;
		cout << user << endl;
	}
}

bool isBoardFull() {

	for (int row = 0; row < NUM_ROWS; row++) // makes sure that the board is not full
	{
		for (int column = 0; column < NUM_COLUMNS; column++) {
			if (tictactoe_game[row][column] == ' ')
			{
				return false;
			}
		}
	}

	return true;
}

void AImove() {
	if (!isBoardFull()) {
		RNG();
	}
}



void RNG() { // a function to place the computers move in a random location
	int random1;
	int random2;
	bool check = false;

	srand(time(0));

	while (check == false) {
		random1 = rand() % 3;
		random2 = rand() % 3;
		if (tictactoe_game[random1][random2] == ' ') {
			tictactoe_game[random1][random2] = 'O';
			check = true;
		}
	}
}