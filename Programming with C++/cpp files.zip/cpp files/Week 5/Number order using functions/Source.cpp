#include <iostream>
#include <string>

using namespace std;

int highest4(int first, int second, int third, int fourth); // a function that will compare 4 numbers
int higher(int x, int y); // a function that compares two numbers
int higher10(int first, int second, int third, int fourth, int fifth, int sixth, int seventh, int eigth, int ninth, int tenth); // a function that takes in all the numebrs


int main() {

	//set all ten variables to ten
	int first = 0; int second = 0; int larger = 0;
	int third = 0; int fourth = 0; int fifth = 0;
	int sixth = 0; int seventh = 0; int eigth = 0;
	int ninth = 0; int tenth = 0;
	

	// get the user input for each number
	cout << "Enter the first score" << endl;
	cin >> first;

	cout << "Enter the second score" << endl;
	cin >> second;

	cout << "Enter the third score" << endl;
	cin >> third;

	cout << "Enter the fourth score" << endl;
	cin >> fourth;

	cout << "Enter the fifth score" << endl;
	cin >> fifth;

	cout << "Enter the sixth score" << endl;
	cin >> sixth;

	cout << "Enter the seventh score" << endl;
	cin >> seventh;

	cout << "Enter the eigth score" << endl;
	cin >> eigth;

	cout << "Enter the ninth score" << endl;
	cin >> ninth;

	cout << "Enter the tenth score" << endl;
	cin >> tenth;


	cout << "The highest number is " << higher10(first, second, third, fourth, fifth, sixth, seventh, eigth, ninth, tenth) << endl; // output the highest number by calling highest ten

}

int highest4(int first, int second, int third, int fourth) { // compares 4 numbers together
	int comparison1;
	int comparison2;
	int highest;

	comparison1 = higher(first, second); // finds out which is the highest of the two numbers
	comparison2 = higher(third, fourth);// finds out which is the highest of the two numbers
	highest = higher(comparison1, comparison2); // finds out which is the highest number out of the reult of the previous two function calls

	return highest; // returns the highest out of the 4 numbers
}

int higher(int x, int y) { // compares two numbers together

	if (x > y) {  // if number 1 is greater than number two, then it is the highest number, otherwise numer 2 is the highest number
		return x;
	}
	else return y;

}

int higher10(int first, int second, int third, int fourth, int fifth, int sixth, int seventh, int eigth, int ninth, int tenth) {

	int comparison1 = 0;
	int highest = 0;

	comparison1 = higher((highest4(first, second, third, fourth)), (highest4(fifth, sixth, seventh, eigth))); // takes the first 8 numbers, splits them into two groups, then finds out what is the highest number from the products of the two group 
	highest = higher((higher(ninth, tenth)), comparison1); // finds out the largest number

	return highest; // returns the oevrall largest number

}

