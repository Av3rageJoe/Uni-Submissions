#include <iostream>
using namespace std;

bool isValidDimensions(double length, double dia);
double eval_volume(double length, double diameter);
double eval_weight(double est_volume, double num);
void wedge_or_cylinder(double est, double act);

int main()
{
	// set initial variables
	double length = 0;  double diameter = 0; double act_weight = 0;
	double est_volume = 0; double est_weight = 0;

	// receive the user inputs
	cout << "Enter the length in mm: " << endl;
	cin >> length;

	cout << "Enter the diameter in mm: " << endl;
	cin >> diameter;

	cout << "Enter the weight in grams: " << endl;
	cin >> act_weight;

	if (!isValidDimensions(length, diameter))
		// check len is within the range 1mm to 20mm and dia is in range 0.1mm - 1mm
	{
		cout << "Dimensions are not valid";
	}
	else
	{
		// estimate volume
		est_volume = eval_volume(length, diameter);
		// estimate weight, density 0.05
		est_weight = eval_weight(est_volume, 0.05);
		// display if wedge or cylinder
		wedge_or_cylinder(est_weight, act_weight);
	}

	return 0;
}

bool isValidDimensions(double length, double dia) { // checks to make sure that the length and diameters entered are valid.
	if ((length < 1 || length > 20) || (dia < 0.1 || dia > 1)) {
		return false;
	}
	else return true;

}

double eval_volume(double length, double diameter) {
	int pi = 3.142;
	int volume = 0;

	volume = pi * ((diameter / 2) * (diameter / 2)) * length; // calculates the volume

	return volume;
}

double eval_weight(double est_volume, double num) {
	double weight = 0;

	weight = est_volume * num; // calculates the weight

	return weight;
}

void wedge_or_cylinder(double est, double act) {
	double difference = est - act; // finds out the difference between the estemated and actual weight

	if (difference < -0.1 || difference > 0.1) {
		cout << "The shard is wedge shaped." << endl;
	}
	else cout << "The shard is cylinder shaped" << endl;
}
