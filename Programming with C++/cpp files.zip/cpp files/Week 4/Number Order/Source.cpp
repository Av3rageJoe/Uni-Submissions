#include <iostream>
using namespace std;

void sorting();


int main()
{
	sorting(); // call the sorting function

}

void sorting() {
	int numbers[10];

	for (int i = 0; i < 10; i++) // a for loop to run ten times
	{
		cout << "Please enter a number" << endl;
		cin >> numbers[i];

	}

	for (int i = 0; i < 10; i++)
	{

		for (int j = 0; j < 9; j++) { // a loop that will compare the value of one array to the previous value ofthe array

			if (numbers[j] > numbers[j + 1])  // if the number in one position in the array is greater than the number in the following position
			{
				int temp = numbers[j + 1]; //store the lower number in a avriable called temp
				numbers[j + 1] = numbers[j]; // move the lower number to the previous spot in the array
				numbers[j] = temp; // move the higher number into the following position in the array (swap the numbers position in the array around)
			}
		}
	}

	for (int i = 0; i < 10; i++) // a loop to display each number in the array
	{
		cout << endl;
		cout << numbers[i] << endl; // displays the sorted array.
	}
}