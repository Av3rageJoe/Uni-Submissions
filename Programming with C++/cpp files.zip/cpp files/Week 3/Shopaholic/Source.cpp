#include <iostream>

using namespace std;

int main()
{
	double item1 = 0, item2 = 0, item3 = 0, item4 = 0, item5 = 0, item6 = 0; // variables to store the price of each object
	double discount = 0, total = 0; // variables to store the discount and total cost
	int i = 0;
	bool check = false;

	while (check == false) {
		cout << "Please enter the value of the items in descending order \n";
		for (i = 0; i < 6; i++) // for each number inputted it will store the input in a different variable
		{
			switch (i) {
			case 0: cin >> item1; break;
			case 1: cin >> item2; break;
			case 2: cin >> item3; break;
			case 3: cin >> item4; break;
			case 4: cin >> item5; break;
			case 5: cin >> item6; break;

			default: cout << "Please try again, error";
			}

		}
		if ((item1 > item2 && item1 > item3) && (item4 > item5 && item4 > item6)) // makes sure the user enters the numbers in descending order
		{
			discount = discount + item3 + item6; // adds the discount of the cost of the third and sixth item
			check = true;
		}
		else {
			cout << "You did not enter the values in the correct order. Please try again \n";
		}
	}

	total = item1 + item2 + item3 + item4 + item5 + item6; // calculates the total

	//outputs results
	cout << "The total cost without a discount is " << char(156) << total << endl; 
	cout << "The total discount is " << char(156) << discount << endl;
	cout << "The total price to pay is " << char(156) << total - discount << endl;


}