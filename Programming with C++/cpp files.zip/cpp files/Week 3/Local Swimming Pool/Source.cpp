#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	double under16 = 0, over65 = 0, others = 0, cost = 0; // declares variables
	int age = 0, total = 0; // declare variables

	cout << "\tPrice per person:" << endl;
	cout << endl;
	cout << "\t \t Under 16's - " << char(156) << "2.50" << endl;
	cout << "\t \t Over 65 - " << char(156) << "3.00" << endl;
	cout << "\t \t All other swimmers - " << char(156) << "5" << endl;
	cout << endl;
	cout << "\t For groups of six or more, you will receive a 20% discount." << endl;
	cout << endl;

	while (age != -1) // runs until the user enters -1
	{
		cout << "\t Please enter the age of the swimmer ( or - 1 to calculate the total cost)" << endl;
		cin >> age; // get the user input of how old the person is
		if (age < 16 && age > 0) // for people under the age of 16
		{
			under16++; // increment the under 16 variable by one
			total++; // increment the total variable by one
			cost = cost + 2.50; // and �2.50 to the total cost
		}
		else if (age > 64) // for people who are over 65
		{
			over65++; 
			total++;
			cost = cost + 3;
		}
		else if (age >= 16 && age <= 64)
		{
			others++;
			total++;
			cost = cost + 5;
		}
	}
	if (total >= 6)
	{
		cost = cost * 0.8; // apply the 20% discount if the group is larger than 6 or more people
	}

	cout << "The total number of people going is " << total << endl; // output how many people are going
	cout << "the total cost is " << char(156) << setprecision(2) << fixed << cost << endl; // output the total cost to two decimal points.

	return 0;
}